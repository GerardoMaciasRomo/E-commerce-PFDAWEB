const t_shirts = [
    {
        id: 1,
        name: "shirt1",
        image: "../assets/img/shirt_prueba.webp",
        price: 342
    },
    {
        id: 2,
        name: "shirt2",
        image: "../assets/img/shirt_prueba.webp",
        price: 342
    },
    {
        id: 3,
        name: "shirt3",
        image: "../assets/img/shirt_prueba.webp",
        price: 342
    },
    {
        id: 4,
        name: "shirt4",
        image: "../assets/img/shirt_prueba.webp",
        price: 342
    },
    {
        id: 5,
        name: "shirt5",
        image: "../assets/img/shirt_prueba.webp",
        price: 342
    },
    {
        id: 6,
        name: "shirt6",
        image: "../assets/img/shirt_prueba.webp",
        price: 342
    },
    {
        id: 7,
        name: "shirt7",
        image: "../assets/img/shirt_prueba.webp",
        price: 342
    },
    {
        id: 8,
        name: "shirt8",
        image: "../assets/img/shirt_prueba.webp",
        price: 342
    },

];