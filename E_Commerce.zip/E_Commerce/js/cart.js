//ADD TO CART
async function add_to_cart(product) {
    try {
        const response = await fetch('http://localhost:4000/cart/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                id: product.id,
                name: product.name,
                amount: 1,
                price: product.price
            })
        });
        if (!response.ok) throw new Error('Error adding product to cart');
        
        // Actualiza elementos en el carrito
        n_items().then(n_items =>{
            update_number_of_items(n_items);
        })
        update().then(products =>{
            update_cart(products);
        })
        cart_empty().then(total =>{
            is_cart_empty(total);
        })


    } catch (error) {
        console.error('Failed to add product to cart:', error);
    }
}
/*ADD TO CART*/



/*DELETE FROM CART*/
async function delete_from_cart(product){
    try {
        const response = await fetch('http://localhost:4000/cart/delete', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                id: product.id
            })
        });

        if (!response.ok) throw new Error('Error deleting product to cart');
        
        // Actualiza elementos en el carrito
        n_items().then(n_items =>{
            console.log("no jala")
            update_number_of_items(n_items);
        })
        update().then(products =>{
            console.log("no jala")
            update_cart(products);
        })
        cart_empty().then(total =>{
            is_cart_empty(total);
        })


    } catch (error) {
        console.error('Failed to delete product to cart:', error);
    }
}
/*DELETE FROM CART*/


/*UPDATE NUMBER OF ITEMS */
function update_number_of_items(n_items){
    const number_of_items = document.getElementById("number_of_items");

    number_of_items.innerText = n_items;
}

n_items().then(n_items =>{
    update_number_of_items(n_items);
})
/*UPDATE NUMBER OF ITEMS */


/*CHECK IF CART IS EMPTY*/
function is_cart_empty(total) {
    const empty_cart = document.getElementById("empty_cart");
    const tot = document.getElementById("total");
    /*console.log(total);*/

    if(empty_cart && tot){
        if (total[0].amount_sum == 0) {
            // Si el carrito está vacío, muestra "empty_cart" y oculta "tot"
            empty_cart.classList.remove("hidden");
            tot.classList.add("hidden");
        } else {
            // Si hay productos, muestra "tot" y oculta "empty_cart"
            empty_cart.classList.add("hidden");
            tot.classList.remove("hidden");
    
            const total_units = document.getElementById('total_units');
            const total_price = document.getElementById('total_price');
            total_units.innerText = total[0].amount_sum;
            total_price.innerText = total[0].prices_sum;
            //Si la activo hace muchas consultas por eso lo comenté
            /*cart_empty().then(total =>{
                is_cart_empty(total);
            })*/
        }
    }
}


cart_empty().then(total =>{
    is_cart_empty(total);
})
/*CHECK IF CART IS EMPTY*/