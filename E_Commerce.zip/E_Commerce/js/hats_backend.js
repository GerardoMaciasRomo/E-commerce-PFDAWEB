async function get_hats(){
    const res = await fetch('http://localhost:4000/hats');
    const resJson = await res.json();
    return resJson;
}