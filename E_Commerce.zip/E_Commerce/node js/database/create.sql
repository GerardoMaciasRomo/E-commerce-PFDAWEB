CREATE database e_commerce;

use e_commerce;

/*T_SHIRTS*/
create table t_shirts(
	id integer primary key auto_increment,
    name text,
    img text,
    price int
);

insert into t_shirts (name, price)
values ("shirt1", 397),
	   ("shirt2", 339),
       ("shirt3", 544),
       ("shirt4", 760),
       ("shirt5", 633),
       ("shirt6", 445),
       ("shirt7", 300),
       ("shirt8", 420);

select * from t_shirts;
/*T_SHIRTS*/

/*HOODIES*/
create table hoodies(
	id integer primary key,
    name text,
    img text,
    price int
);

insert into hoodies (id, name, price)
values (9, "hoodie1", 397),
	   (10, "hoodie2", 339),
       (11, "hoodie3", 544),
       (12, "hoodie4", 760),
       (13, "hoodie5", 633),
       (14, "hoodie6", 445),
       (15, "hoodie7", 300),
       (16, "hoodie8", 420);

select * from hoodies;
/*HOODIES*/

/*HATS*/
create table hats(
	id integer primary key,
    name text,
    img text,
    price int
);

insert into hats (id, name, price)
values (17, "hat1", 397),
	   (18, "hat2", 339),
       (19, "hat3", 544),
       (20, "hat4", 760),
       (21, "hat5", 633),
       (22, "hat6", 445),
       (23, "hat7", 300),
       (24, "hat8", 420);

select * from hats;
/*HATS*/

/*PHONE CASES*/
create table phone_cases(
	id integer primary key,
    name text,
    img text,
    price int
);

insert into phone_cases (id, name, price)
values (25, "phone_case1", 397),
	   (26, "phone_case2", 339),
       (27, "phone_case3", 544),
       (28, "phone_case4", 760),
       (29, "phone_case5", 633),
       (30, "phone_case6", 445),
       (31, "phone_case7", 300),
       (32, "phone_case8", 420);

select * from phone_cases;
/*PHONE CASES*/


create table cart(
	user_id int,
    product_id int,
	product_amount int
);

select * from cart;