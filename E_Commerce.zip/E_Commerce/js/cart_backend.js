async function update(){
    const res = await fetch('http://localhost:4000/cart/update');
    const resJson = await res.json();
    return resJson;
}

async function n_items() {
    const res = await fetch('http://localhost:4000/cart/items');
    const resJson = await res.json();
    
    // Acceder al número de productos, que está en resJson[0]['count(product_amount)']
    return resJson[0]['SUM(product_amount)'];
}

async function cart_empty(){
    const res = await fetch('http://localhost:4000/cart/empty');
    const resJson = await res.json();

    return resJson;
}
