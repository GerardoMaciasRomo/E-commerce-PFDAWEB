create table t_shirts(
	id integer primary key auto_increment,
    name text,
    img text,
    price int
);