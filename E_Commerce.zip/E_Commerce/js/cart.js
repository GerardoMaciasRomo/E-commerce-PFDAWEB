/*ADD TO CART*/
function add_tshirt_to_cart(product){
    let count = 1;

    const memory = JSON.parse(localStorage.getItem("T_SHIRTS"));

    /*console.log(memory);*/

    if(!memory){
        const new_product = get_new_product_for_memory(product);
        localStorage.setItem("T_SHIRTS", JSON.stringify([new_product]));
    }
    else{
        const product_idx = memory.findIndex(curr_t_shirt => curr_t_shirt.id === product.id);
        
        /*console.log(product_idx);*/

        const new_memory = memory;
        if(product_idx === -1){
            const new_product = get_new_product_for_memory(product);
            new_memory.push(new_product);
        }
        else{
            new_memory[product_idx].amount++;
            count = new_memory[product_idx].amount;
        }

        localStorage.setItem("T_SHIRTS", JSON.stringify(new_memory));
    }

    update_number_of_items();
    return count;
}

function add_hoodies_to_cart(product){

}
function add_hats_to_cart(product){

}
function add_phoneCases_to_cart(product){

}
/*ADD TO CART*/



/*DELETE FROM CART*/
function delete_tshirt_from_cart(product){
    let count = 0;
    /*console.log(product);*/

    const memory = JSON.parse(localStorage.getItem("T_SHIRTS"));
    const product_idx = memory.findIndex(curr_t_shirt => curr_t_shirt.id === product.id);

    if(memory[product_idx].amount == 1)
        memory.splice(product_idx, 1);
    else{
        memory[product_idx].amount--;
        count = memory[product_idx].amount;
    }

    localStorage.setItem("T_SHIRTS", JSON.stringify(memory));

    update_number_of_items();
    return count;
}

function delete_hoodies_from_cart(product){

}
function delete_hats_from_cart(product){

}
function delete_phoneCases_from_cart(product){

}
/*DELETE FROM CART*/



function get_new_product_for_memory(product){
    const new_product = product;
    new_product.amount = 1;
    return  new_product;
}

function update_number_of_items(){
    const number_of_items = document.getElementById("number_of_items");

    const categories = ["T_SHIRTS", "HOODIES", "HATS", "PHONECASES"];
    let memory;
    let count = 0;

    categories.forEach(category => {
        memory = JSON.parse(localStorage.getItem(category));
        if(memory)
            count = memory.reduce((sum, curr) => sum + curr.amount, count);
    });

    number_of_items.innerText = count;

    /*const number_of_items = document.getElementById("number_of_items");
    number_of_items.innerText++;*/
}

update_number_of_items();


function is_cart_empty(){
    const empty_cart = document.getElementById("empty_cart");
    const total = document.getElementById("total");
    const categories = ["T_SHIRTS", "HOODIES", "HATS", "PHONECASES"];
    let memory, items = 0;

    for(let category of categories) {
        memory = JSON.parse(localStorage.getItem(category));
        if(memory && memory.length > 0) {
            items = 1;
            break;
        }
    }

    empty_cart.classList.toggle("hidden", items);
    total.classList.toggle("hidden", !items);
}

is_cart_empty();