async function get_hoodies(){
    const res = await fetch('http://localhost:4000/hoodies');
    const resJson = await res.json();
    return resJson;
}