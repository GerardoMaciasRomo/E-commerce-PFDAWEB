const products_container = document.getElementById('products_container');


function update_cart(){
    const categories = ["T_SHIRTS", "HOODIES", "HATS", "PHONECASES"];
    const prod = ["tshirt", "hoodies", "hats", "phonecases"];
    let idx = 0;
    let products;

    categories.forEach(category => {
        products = JSON.parse(localStorage.getItem(category));
        if(products){
            /*console.log(products);*/

            products.forEach(product => {
                const new_product = document.createElement("div");
                new_product.id = `${product.name}_${product.id}`;

                new_product.innerHTML = `
                    <img src= ${product.image}>
                    <h3>${product.name}</h3>
                    <p>$${product.price}</p>
                    <div>
                        <button>-</button>
                        <span class="amount">${product.amount}</span>
                        <button>+</button>
                    </div>
                `;

                products_container.appendChild(new_product);

                let del = `delete_${prod[idx]}_from_cart`;
                new_product.getElementsByTagName("button")[0].addEventListener("click", (e) => {
                    const count = e.target.parentElement.getElementsByTagName("span")[0];
                    count.innerText = window[del](product);
                
                    products_container.innerHTML = "";
                    update_total();
                    update_cart();
                });

                let add = `add_${prod[idx]}_to_cart`;
                new_product.getElementsByTagName("button")[1].addEventListener("click", (e) => {
                    const count = e.target.parentElement.getElementsByTagName("span")[0];
                    count.innerText = window[add](product);

                    products_container.innerHTML = "";
                    update_total();
                    update_cart();
                });
            })
        }
        idx++;
    })
}

const total_units = document.getElementById('total_units');
const total_price = document.getElementById('total_price');
function update_total(){
    const categories = ["T_SHIRTS", "HOODIES", "HATS", "PHONECASES"];
    let products;
    let units = 0, price = 0;

    categories.forEach(category => {
        products = JSON.parse(localStorage.getItem(category));
        if(products){
            products.forEach(product => {
                units += product.amount;
                price += product.price*product.amount;
            })
        }
    })

    total_units.innerText = units;
    total_price.innerText = price;

    is_cart_empty();
}

update_cart();
update_total();



const del_cart = document.getElementById("delete_cart");
del_cart.addEventListener("click", delete_cart);
function delete_cart(){
    const categories = ["T_SHIRTS", "HOODIES", "HATS", "PHONECASES"];

    for(let category of categories)
        localStorage.removeItem(category);
    products_container.innerHTML = "";
    update_number_of_items();
    is_cart_empty();
}